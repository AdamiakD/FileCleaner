﻿using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;


namespace speracz
{
    public partial class Form1 : Form
    {
        string progpos = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\";
        string[] lst2 = new String[100000];
        DateTime timenow = DateTime.Now;
        ArrayList al = new ArrayList();
        string[] config = new string[10];
        int ile_dni = 0;
        string searchpath = "";
        string mailrecip = "";
        string addrsmtp = "";
        string pass = "";
        string port = "";
        string msender = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, System.EventArgs e)
        {
            textBox2.Text = "";
            txtFile.Enabled = false;
            textBox1.Enabled = false;
            btnSearch.Enabled = false;
            btnSearch.Text = "Skanuję...";
            this.Cursor = Cursors.WaitCursor;
            Application.DoEvents();
            DirSearch(textBox1.Text);
            btnSearch.Enabled = true;
            btnSearch.Text = "Skanuj";
            this.Cursor = Cursors.Default;
            txtFile.Enabled = true;
            textBox1.Enabled = true;
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            try
            {
                //string apppath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                config = File.ReadAllLines(progpos + "config.ini");
                textBox1.Text = config[0];
                searchpath = config[0];
                mailrecip = config[1];
                addrsmtp = config[2];
                port = config[3];
                msender = config[4];
                pass = config[5];
                ile_dni = Convert.ToInt16(config[6]);
                textBox3.Text = config[1];
                label2.Visible = true;
                Application.DoEvents();
                string[] zasoby = textBox1.Text.Split('|');
                foreach (string zasob in zasoby)
                {
                    DirSearch(zasob);
                }

                label2.Visible = false;
                if (label2.Visible == false) Application.Exit();
            }
            catch (System.Exception excpt)
            {
                File.AppendAllText(progpos + "log.log", DateTime.Now.ToString() + "  " + excpt.ToString());
            }
        }

        void DirSearch(string sDir)
        {
            try
            {

                foreach (string d in Directory.GetDirectories(sDir))
                {

                    if (d.ToUpper().IndexOf("!") == -1)
                    {
                        foreach (string f in Directory.GetFiles(d))
                        {
                            if (f.ToUpper().IndexOf("!") == -1 & f.ToUpper().IndexOf("RAPORT") == -1)
                            {
                                if (d.ToUpper().IndexOf("!") == -1)     //wyjatek dla nazw z "!"
                                {
                                    DateTime filedata = File.GetLastWriteTime(f);
                                    if (timenow >= filedata.AddDays(ile_dni))
                                    {
                                        if (d.ToUpper().IndexOf("LAY") == -1 & d.ToUpper().IndexOf("PROOF") == -1)
                                        {
                                            if (Path.GetExtension(f).ToUpper() == ".XML" |
                                                Path.GetExtension(f).ToUpper() == ".PGP" |
                                                Path.GetExtension(f).ToUpper() == ".XLS" |
                                                Path.GetExtension(f).ToUpper() == ".XLSX" |
                                                Path.GetExtension(f).ToUpper() == ".CSV" |
                                                Path.GetExtension(f).ToUpper() == ".DBF" |
                                                Path.GetExtension(f).ToUpper() == ".TXT" |
                                                Path.GetExtension(f).ToUpper() == ".PS" |
                                                Path.GetExtension(f).ToUpper() == ".ZIP" |
                                                Path.GetExtension(f).ToUpper() == ".7Z" |
                                                Path.GetExtension(f).ToUpper() == ".INI" |
                                                Path.GetExtension(f).IndexOf(".0") > -1 | Path.GetExtension(f).IndexOf(".1") > -1 |
                                                Path.GetExtension(f).ToUpper() == ".DBF" |
                                                (Path.GetExtension(f).ToUpper() == ".PDF" & d.ToUpper().IndexOf("PODAJNIK") == -1))
                                            {
                                                File.Delete(f);
                                                textBox2.Text = textBox2.Text + f + "; data ostatniego dostępu: " + filedata.ToString() + ",\r\n";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //	                	if (Directory.GetFiles(d).Length <= 0 && Directory.GetDirectories(d).Length <=0)
                        //	                	{
                        //	                		Directory.Delete(d);
                        //	                	}           		
                    }
                    DirSearch(d);
                }
            }
            catch (System.Exception excpt)
            {
                //MessageBox.Show(excpt.ToString());
                File.AppendAllText(progpos + "log.log", DateTime.Now.ToString() + "  " + excpt.ToString());
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (textBox2.Text.Trim() != "")
                {
                    //                  SmtpClient smtp = new System.Net.Mail.SmtpClient(addrsmtp,Convert.ToInt32(port));
                    //		            smtp.DeliveryMethod = SmtpDeliveryMethod.Network; 
                    //		            smtp.EnableSsl = true;
                    //		            smtp.Credentials = new System.Net.NetworkCredential(msender,pass);
                    //		            smtp.Send(msender, mailrecip, "DBCleaner usunął dane...", textBox2.Text);

                    //		            string to = msender;
                    //				    string from = msender;
                    //				    MailMessage message = new MailMessage(from, to);
                    //				    message.Subject = "DBCleaner usunął dane...";
                    //				    message.Body = @textBox2.Text;
                    //				    SmtpClient client = new SmtpClient(addrsmtp);
                    //				    client.Credentials = new System.Net.NetworkCredential(msender,pass);
                    //				    client.Send(message);


                    File.WriteAllText(progpos + "Raporty/" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0')
                             + "_" + DateTime.Now.Hour.ToString().PadLeft(2, '0') + DateTime.Now.Minute.ToString().PadLeft(2, '0') + DateTime.Now.Second.ToString().PadLeft(2, '0')
                          + "_raport.txt", textBox2.Text);

                }
            }
            catch (System.Exception excpt)
            {
                File.AppendAllText(progpos + "log.log", DateTime.Now.ToString() + "  " + excpt.ToString());
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK
                            && folderBrowserDialog1.SelectedPath.Length > 0)
            {
                textBox1.Text = folderBrowserDialog1.SelectedPath;
            }
            else return;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            config[0] = textBox1.Text;
            File.WriteAllLines(progpos + "config.ini", config);

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            config[1] = textBox3.Text;
            File.WriteAllLines(progpos + "config.ini", config);
        }
    }
}
